(function () {
'use strict';

/* ---- src/engine/suspend-codec.js ----------------------------------------- */
/**
 * Compact codec for cmi.suspend_data (bookmarking / resume state).
 *
 * SCORM 1.2 guarantees only 4096 characters of suspend_data, and several
 * production LMSs truncate silently at exactly that boundary. JSON is therefore
 * not safe for a course of this size, so progress is serialised into a short
 * positional string instead.
 *
 * Wire format (version 1), pipe-delimited:
 *
 *   1|<pageIndex>|<visitedBitfield>|<kcState>|<elapsedSeconds>|<ackFlags>
 *
 *   pageIndex        base-36 index of the page the learner was last on
 *   visitedBitfield  base-36 run of 5-bit groups, one bit per page, LSB first
 *   kcState          base-36 pairs: <pageIndex><outcome> for answered knowledge
 *                    checks, outcome 1 = correct, 0 = incorrect
 *   elapsedSeconds   base-36 accumulated instructional seconds
 *   ackFlags         base-36 bitfield of acknowledgement checkboxes (attestations)
 *
 * A 400-page course encodes in well under 400 characters, leaving ample margin
 * inside the 4096-character floor.
 */

const VERSION = 1;
const RADIX = 36;
const BITS_PER_GROUP = 5;

const toBase36 = (n) => Math.max(0, Math.trunc(n)).toString(RADIX);
const fromBase36 = (s) => {
  const n = parseInt(s, RADIX);
  return Number.isFinite(n) ? n : 0;
};

function encodeBitfield(flags) {
  if (!flags || flags.length === 0) return '';
  const groups = [];
  for (let i = 0; i < flags.length; i += BITS_PER_GROUP) {
    let value = 0;
    for (let bit = 0; bit < BITS_PER_GROUP; bit += 1) {
      if (flags[i + bit]) value |= 1 << bit;
    }
    groups.push(value.toString(RADIX));
  }
  // Trim trailing all-zero groups; decode re-pads to the expected length.
  while (groups.length && groups[groups.length - 1] === '0') groups.pop();
  return groups.join('');
}

function decodeBitfield(encoded, length) {
  const flags = new Array(length).fill(false);
  if (!encoded) return flags;
  for (let g = 0; g < encoded.length; g += 1) {
    const value = fromBase36(encoded[g]);
    for (let bit = 0; bit < BITS_PER_GROUP; bit += 1) {
      const index = g * BITS_PER_GROUP + bit;
      if (index >= length) break;
      flags[index] = Boolean(value & (1 << bit));
    }
  }
  return flags;
}

function encodeKnowledgeChecks(map) {
  const keys = Object.keys(map || {})
    .map(Number)
    .filter((n) => Number.isInteger(n) && n >= 0)
    .sort((a, b) => a - b);
  return keys.map((k) => `${toBase36(k)}.${map[k] ? 1 : 0}`).join(',');
}

function decodeKnowledgeChecks(encoded) {
  const map = {};
  if (!encoded) return map;
  for (const pair of encoded.split(',')) {
    if (!pair) continue;
    const [key, outcome] = pair.split('.');
    map[fromBase36(key)] = outcome === '1';
  }
  return map;
}

/**
 * @param {{pageIndex:number, visited:boolean[], knowledgeChecks:Object<number,boolean>,
 *          elapsedSeconds:number, acknowledgements:boolean[]}} state
 * @returns {string}
 */
function encodeState(state) {
  const parts = [
    VERSION,
    toBase36(state.pageIndex || 0),
    encodeBitfield(state.visited || []),
    encodeKnowledgeChecks(state.knowledgeChecks),
    toBase36(state.elapsedSeconds || 0),
    encodeBitfield(state.acknowledgements || []),
  ];
  return parts.join('|');
}

/**
 * Tolerant of empty, truncated or foreign suspend_data: a learner whose state
 * cannot be read resumes at the start of the course rather than seeing an error.
 *
 * @param {string} raw
 * @param {{pageCount:number, acknowledgementCount?:number}} shape
 */
function decodeState(raw, shape) {
  const pageCount = shape?.pageCount ?? 0;
  const ackCount = shape?.acknowledgementCount ?? 0;
  const empty = {
    pageIndex: 0,
    visited: new Array(pageCount).fill(false),
    knowledgeChecks: {},
    elapsedSeconds: 0,
    acknowledgements: new Array(ackCount).fill(false),
    recovered: false,
  };
  if (typeof raw !== 'string' || raw.length === 0) return empty;

  const parts = raw.split('|');
  if (fromBase36(parts[0]) !== VERSION) return empty;

  const pageIndex = fromBase36(parts[1]);
  return {
    pageIndex: pageIndex < pageCount ? pageIndex : 0,
    visited: decodeBitfield(parts[2] || '', pageCount),
    knowledgeChecks: decodeKnowledgeChecks(parts[3] || ''),
    elapsedSeconds: fromBase36(parts[4] || '0'),
    acknowledgements: decodeBitfield(parts[5] || '', ackCount),
    recovered: true,
  };
}

const SUSPEND_DATA_LIMIT_SCORM_12 = 4096;
const SUSPEND_DATA_LIMIT_SCORM_2004 = 64000;

/* ===========================================================================
   Examination state
   ===========================================================================
   An examination attempt must survive a browser crash, a dropped connection or
   a learner who closes the tab, and must resume on the identical form -- a
   fresh draw mid-attempt would be a different test. Only the seed is stored,
   not the items, so the state stays tiny and the form is rebuilt
   deterministically.

   Wire format (version 1):

     E1|<attempt>|<seed>|<elapsedSeconds>|<responses>|<submittedFlag>|<bestPercentx100>

   responses: one base-36 character per item, '.' where the item is unanswered.

   A single-answer item stores its selected option index. A multiple-response
   item stores a bitmask of the options selected, which fits one base-36
   character for up to five options -- the maximum the item bank uses. Decoding
   needs to know which items are multiple response, so the caller passes the
   form's flags.
   ========================================================================= */

/** Largest option count a multiple-response item can have in one base-36 digit. */
const MAX_MULTI_OPTIONS = 5;

const EXAM_VERSION = 'E1';
const UNANSWERED = '.';

function encodeExamState(state) {
  const responses = (state.responses || [])
    .map((r) => {
      if (r === null || r === undefined) return UNANSWERED;
      if (Array.isArray(r)) {
        if (r.length === 0) return UNANSWERED;
        let mask = 0;
        for (const i of r) {
          if (i >= MAX_MULTI_OPTIONS) return UNANSWERED; // beyond what one digit holds
          mask |= 1 << i;
        }
        return mask.toString(RADIX);
      }
      return Math.trunc(r).toString(RADIX);
    })
    .join('');
  return [
    EXAM_VERSION,
    toBase36(state.attempt || 1),
    toBase36(state.seed || 0),
    toBase36(state.elapsedSeconds || 0),
    responses,
    state.submitted ? '1' : '0',
    toBase36(Math.round((state.bestPercent || 0) * 100)),
  ].join('|');
}

/**
 * @param {string} raw
 * @param {number} itemCount
 * @param {boolean[]} [multipleFlags] true for each multiple-response item
 */
function decodeExamState(raw, itemCount, multipleFlags = []) {
  const empty = {
    attempt: 1,
    seed: 0,
    elapsedSeconds: 0,
    responses: new Array(itemCount).fill(null),
    submitted: false,
    bestPercent: 0,
    recovered: false,
  };
  if (typeof raw !== 'string' || !raw.startsWith(`${EXAM_VERSION}|`)) return empty;
  const parts = raw.split('|');
  const responses = new Array(itemCount).fill(null);
  const encoded = parts[4] || '';
  for (let i = 0; i < itemCount; i += 1) {
    const ch = encoded[i];
    if (!ch || ch === UNANSWERED) continue;
    const value = fromBase36(ch);
    if (multipleFlags[i]) {
      const picked = [];
      for (let bit = 0; bit < MAX_MULTI_OPTIONS; bit += 1) {
        if (value & (1 << bit)) picked.push(bit);
      }
      responses[i] = picked;
    } else {
      responses[i] = value;
    }
  }
  return {
    attempt: Math.max(1, fromBase36(parts[1] || '1')),
    seed: fromBase36(parts[2] || '0'),
    elapsedSeconds: fromBase36(parts[3] || '0'),
    responses,
    submitted: parts[5] === '1',
    bestPercent: fromBase36(parts[6] || '0') / 100,
    recovered: true,
  };
}

/* ---- src/engine/scorm-api.js --------------------------------------------- */
/**
 * SCORM run-time abstraction.
 *
 * Discovers and drives either a SCORM 1.2 (`API`) or SCORM 2004 4th Edition
 * (`API_1484_11`) adapter and presents one interface to the player, so a single
 * content source builds against both packaging formats.
 *
 * Deliberately dependency-free and defensive: every LMS call is wrapped, a
 * missing adapter degrades to an in-memory store (so the course still runs when
 * launched outside an LMS for review), and no call is allowed to throw into the
 * learner's session.
 */


const SCORM_12 = '1.2';
const SCORM_2004 = '2004';
const SCORM_NONE = 'none';

const MAX_PARENT_WALK = 12;

/** Element names differ between the two specifications. */
const MAP = {
  [SCORM_12]: {
    lessonStatus: 'cmi.core.lesson_status',
    lessonLocation: 'cmi.core.lesson_location',
    sessionTime: 'cmi.core.session_time',
    scoreRaw: 'cmi.core.score.raw',
    scoreMin: 'cmi.core.score.min',
    scoreMax: 'cmi.core.score.max',
    suspendData: 'cmi.suspend_data',
    learnerName: 'cmi.core.student_name',
    learnerId: 'cmi.core.student_id',
    entry: 'cmi.core.entry',
    exit: 'cmi.core.exit',
    masteryScore: 'cmi.student_data.mastery_score',
    launchData: 'cmi.launch_data',
    interactionsCount: 'cmi.interactions._count',
  },
  [SCORM_2004]: {
    completionStatus: 'cmi.completion_status',
    successStatus: 'cmi.success_status',
    lessonLocation: 'cmi.location',
    sessionTime: 'cmi.session_time',
    scoreRaw: 'cmi.score.raw',
    scoreMin: 'cmi.score.min',
    scoreMax: 'cmi.score.max',
    scoreScaled: 'cmi.score.scaled',
    suspendData: 'cmi.suspend_data',
    learnerName: 'cmi.learner_name',
    learnerId: 'cmi.learner_id',
    entry: 'cmi.entry',
    exit: 'cmi.exit',
    progressMeasure: 'cmi.progress_measure',
    scaledPassingScore: 'cmi.scaled_passing_score',
    launchData: 'cmi.launch_data',
    interactionsCount: 'cmi.interactions._count',
  },
};

/** Walks the opener/parent chain the way every LMS launch shape requires. */
function discoverAdapter(root) {
  if (!root) return { api: null, version: SCORM_NONE };
  const candidates = [];
  let win = root;
  for (let i = 0; i < MAX_PARENT_WALK && win; i += 1) {
    candidates.push(win);
    if (win.opener) candidates.push(win.opener);
    const parent = win.parent;
    if (!parent || parent === win) break;
    win = parent;
  }
  for (const candidate of candidates) {
    try {
      if (candidate.API_1484_11) return { api: candidate.API_1484_11, version: SCORM_2004 };
    } catch { /* cross-origin frame — keep walking */ }
  }
  for (const candidate of candidates) {
    try {
      if (candidate.API) return { api: candidate.API, version: SCORM_12 };
    } catch { /* cross-origin frame — keep walking */ }
  }
  return { api: null, version: SCORM_NONE };
}

/** Seconds -> SCORM 1.2 CMITimespan (HHHH:MM:SS.ss). */
function formatTime12(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds * 100) / 100);
  const hours = Math.floor(s / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = s % 60;
  const pad = (n) => String(Math.floor(n)).padStart(2, '0');
  const frac = Math.round((seconds - Math.floor(seconds)) * 100);
  return `${String(hours).padStart(4, '0')}:${pad(minutes)}:${pad(seconds)}.${String(frac).padStart(2, '0')}`;
}

/** Seconds -> SCORM 2004 ISO 8601 duration (PT#H#M#S). */
function formatTime2004(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds * 100) / 100);
  const hours = Math.floor(s / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = Math.round((s % 60) * 100) / 100;
  let out = 'PT';
  if (hours) out += `${hours}H`;
  if (minutes) out += `${minutes}M`;
  out += `${seconds}S`;
  return out;
}

class ScormRuntime {
  /**
   * @param {object} [options]
   * @param {Window} [options.win] window to search for the adapter
   * @param {(msg:string, detail?:any)=>void} [options.log]
   */
  constructor(options = {}) {
    const { api, version } = discoverAdapter(options.win ?? (typeof window !== 'undefined' ? window : null));
    this.api = api;
    this.version = version;
    this.log = options.log || (() => {});
    this.initialised = false;
    this.terminated = false;
    this.memory = new Map(); // fallback store when launched outside an LMS
    this.lastError = '';
  }

  get isConnected() {
    return this.api !== null;
  }

  get suspendDataLimit() {
    return this.version === SCORM_2004 ? SUSPEND_DATA_LIMIT_SCORM_2004 : SUSPEND_DATA_LIMIT_SCORM_12;
  }

  #call(name12, name2004, args) {
    if (!this.api) return 'true';
    const fn = this.version === SCORM_2004 ? name2004 : name12;
    try {
      return String(this.api[fn](...args));
    } catch (err) {
      this.log(`SCORM ${fn} threw`, err);
      return 'false';
    }
  }

  initialize() {
    if (this.initialised) return true;
    const ok = this.#call('LMSInitialize', 'Initialize', ['']) === 'true';
    this.initialised = ok || !this.api;
    if (!ok && this.api) this.log('SCORM initialise failed', this.getLastError());
    return this.initialised;
  }

  getValue(key) {
    const element = MAP[this.version === SCORM_2004 ? SCORM_2004 : SCORM_12][key] || key;
    if (!this.api) return this.memory.get(element) ?? '';
    const value = this.#call('LMSGetValue', 'GetValue', [element]);
    return value === 'false' && this.getLastError() !== '0' ? '' : value;
  }

  setValue(key, value) {
    const element = MAP[this.version === SCORM_2004 ? SCORM_2004 : SCORM_12][key] || key;
    if (element === undefined) return false;
    if (!this.api) {
      this.memory.set(element, String(value));
      return true;
    }
    if (key === 'suspendData' && String(value).length > this.suspendDataLimit) {
      this.log('suspend_data exceeds the limit for this SCORM version; not written', {
        length: String(value).length,
        limit: this.suspendDataLimit,
      });
      return false;
    }
    const ok = this.#call('LMSSetValue', 'SetValue', [element, String(value)]) === 'true';
    if (!ok) this.log(`SCORM set ${element} failed`, this.getLastError());
    return ok;
  }

  /** Raw element access, for elements outside the mapped set (interactions, objectives). */
  setRaw(element, value) {
    if (!this.api) {
      this.memory.set(element, String(value));
      return true;
    }
    return this.#call('LMSSetValue', 'SetValue', [element, String(value)]) === 'true';
  }

  commit() {
    if (!this.api) return true;
    return this.#call('LMSCommit', 'Commit', ['']) === 'true';
  }

  terminate() {
    if (this.terminated) return true;
    this.terminated = true;
    if (!this.api) return true;
    return this.#call('LMSFinish', 'Terminate', ['']) === 'true';
  }

  getLastError() {
    if (!this.api) return '0';
    try {
      const fn = this.version === SCORM_2004 ? 'GetLastError' : 'LMSGetLastError';
      return String(this.api[fn]());
    } catch {
      return '0';
    }
  }

  /** True when the LMS says this is a resumed attempt. */
  isResumedAttempt() {
    return this.getValue('entry') === 'resume';
  }

  formatDuration(seconds) {
    return this.version === SCORM_2004 ? formatTime2004(seconds) : formatTime12(seconds);
  }

  /**
   * Writes instructional progress. SCORM 1.2 folds completion and mastery into
   * one element; SCORM 2004 separates them, and also carries a progress measure.
   *
   * @param {{complete:boolean, passed?:boolean|null, progress?:number}} status
   */
  setProgress({ complete, passed = null, progress = null }) {
    if (this.version === SCORM_2004) {
      this.setValue('completionStatus', complete ? 'completed' : 'incomplete');
      if (passed !== null) this.setValue('successStatus', passed ? 'passed' : 'failed');
      if (progress !== null) this.setValue('progressMeasure', clamp01(progress).toFixed(4));
      return;
    }
    if (passed !== null) {
      this.setValue('lessonStatus', passed ? 'passed' : 'failed');
    } else {
      this.setValue('lessonStatus', complete ? 'completed' : 'incomplete');
    }
  }

  /**
   * Writes a score in both the raw (0-100) and, on 2004, scaled (0-1) forms.
   * @param {{raw:number, min?:number, max?:number}} score
   */
  setScore({ raw, min = 0, max = 100 }) {
    this.setValue('scoreMin', min);
    this.setValue('scoreMax', max);
    this.setValue('scoreRaw', Math.round(raw * 100) / 100);
    if (this.version === SCORM_2004) {
      const span = max - min || 1;
      this.setValue('scoreScaled', clamp01((raw - min) / span).toFixed(4));
    }
  }

  /** Normal exit, preserving resume state. */
  setSuspendExit() {
    this.setValue('exit', 'suspend');
  }

  /**
   * Reports one scored exam item as a SCORM interaction so the Commonwealth can
   * run item analysis from LMS reporting without a separate data feed.
   *
   * @param {number} index
   * @param {{id:string, type?:string, learnerResponse:string, correctResponse:string,
   *          correct:boolean, weighting?:number, description?:string, objectiveId?:string,
   *          latencySeconds?:number}} interaction
   */
  setInteraction(index, interaction) {
    const n = `cmi.interactions.${index}`;
    const is2004 = this.version === SCORM_2004;
    this.setRaw(`${n}.id`, interaction.id);
    this.setRaw(`${n}.type`, interaction.type || 'choice');
    this.setRaw(`${n}.weighting`, interaction.weighting ?? 1);
    this.setRaw(is2004 ? `${n}.learner_response` : `${n}.student_response`, interaction.learnerResponse);
    this.setRaw(
      is2004 ? `${n}.correct_responses.0.pattern` : `${n}.correct_responses.0.pattern`,
      interaction.correctResponse,
    );
    this.setRaw(`${n}.result`, interaction.correct ? 'correct' : 'incorrect');
    if (interaction.latencySeconds !== undefined) {
      this.setRaw(`${n}.latency`, this.formatDuration(interaction.latencySeconds));
    }
    if (is2004 && interaction.description) {
      this.setRaw(`${n}.description`, interaction.description.slice(0, 250));
    }
    if (interaction.objectiveId) {
      this.setRaw(`${n}.objectives.0.id`, interaction.objectiveId);
    }
    if (is2004) this.setRaw(`${n}.timestamp`, new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'));
  }
}

function clamp01(n) {
  if (!Number.isFinite(n)) return 0;
  return Math.min(1, Math.max(0, n));
}

/* ---- src/player/keep-focus-visible.js ------------------------------------ */
/**
 * Keeps a focused control out from under the sticky page bar.
 *
 * The page bar is `position: sticky; bottom: 0`, so it floats over the bottom
 * of the content while the page is scrolled. A control can therefore be inside
 * the scrollport -- which is the only thing the browser checks -- and still be
 * completely hidden behind the bar. Tab lands on it, the focus ring is drawn
 * underneath the bar, and a keyboard learner cannot see where they are.
 *
 * Measured before this existed: on a knowledge-check screen at 1440x760, the
 * fourth tab stop ("Narration transcript") sat at y 688-707 with the bar
 * starting at y 685. Entirely behind it.
 *
 * CSS cannot fix this. `scroll-margin-bottom` and `scroll-padding-bottom` only
 * apply when the browser decides to scroll, and it does not decide to scroll
 * for an element it already considers visible. So the overlap has to be
 * measured and corrected when focus arrives.
 *
 * WCAG 2.4.11 Focus Not Obscured (Minimum). That is a 2.2 criterion and this
 * project is held to 2.1 AA, so it is not something we are obliged to meet --
 * but a focus ring nobody can see is a defect whichever version names it.
 */

/** How much clear space to leave between the control and the bar. */
const BREATHING_ROOM = 12;

/** True when the element sits inside anything pinned to the viewport. */
function insideStickyBar(el) {
  for (let node = el; node && node !== document.body; node = node.parentElement) {
    const position = getComputedStyle(node).position;
    if (position === 'sticky' || position === 'fixed') return true;
  }
  return false;
}

function keepFocusClearOfStickyBars(root = document) {
  root.addEventListener('focusin', (event) => {
    const el = event.target;
    if (!el || typeof el.getBoundingClientRect !== 'function') return;

    // Only when focus arrived from the keyboard. The problem being corrected
    // is a focus ring the learner cannot see, and a ring is only drawn for
    // keyboard focus. Correcting mouse focus too meant the page scrolled out
    // from under a click in progress: in the examination, clicking Next moved
    // the button 27 pixels mid-click and the sixth question never advanced.
    if (typeof el.matches === 'function' && !el.matches(':focus-visible')) return;

    // A control inside a pinned bar is meant to be there. Decided by computed
    // position rather than by class name, because the examination renders its
    // action row outside the element that carries the .pagebar class, so a
    // class check let its own Next button through.
    if (insideStickyBar(el)) return;

    const bar = root.querySelector?.('.pagebar');
    if (!bar) return;
    const barBox = bar.getBoundingClientRect();
    if (barBox.height === 0) return;

    const box = el.getBoundingClientRect();
    const overlap = box.bottom - barBox.top;
    if (overlap <= 0 || box.top > barBox.bottom) return;    // nowhere near it

    // Scrolling the page moves the control up; the bar stays pinned, so the
    // control ends up clear of it. Instantly, not smoothly: this is a
    // correction to where focus already is, and animating it would be motion
    // the learner did not ask for.
    window.scrollBy({ top: overlap + BREATHING_ROOM, behavior: 'auto' });
  });
}

/* ---- src/player/course-player.js ----------------------------------------- */
/**
 * Module runtime: screen navigation, enforced seat time, and SCORM reporting.
 *
 * One SCO per module, as the storyboards' build standard requires. Within a
 * module the content enforces screen order and the minimum time on each screen;
 * across modules the LMS enforces the pathway.
 *
 * Seat time is the part worth reading carefully. The storyboards say: "The Next
 * button stays locked until the narration ends AND this time has elapsed." So a
 * screen's minimum is a floor on attention, not on wall-clock -- time accrues
 * only while the tab is visible, and where narration audio exists it must also
 * have played to the end on first view. A learner who opens the course and walks
 * away does not accumulate seat time, which is the point of recording it.
 */


const COMMIT_INTERVAL_MS = 60_000;
const TICK_MS = 500;
/** Seat time stops accruing when the learner has been inactive this long. */
const IDLE_AFTER_MS = 180_000;

function startModule(config) {
  const runtime = new ScormRuntime({ log: (m, d) => console.warn('[scorm]', m, d) });
  runtime.initialize();
  keepFocusClearOfStickyBars();

  const screens = config.screens; // [{ id, seconds, lessonId, lessonTitle, type }]
  const screenCount = screens.length;
  const indexById = new Map(screens.map((s, i) => [s.id, i]));

  const restored = decodeState(runtime.getValue('suspendData'), {
    pageCount: screenCount,
    acknowledgementCount: 0,
  });

  const state = {
    index: restored.pageIndex,
    // A screen is "viewed" once its minimum seat time has been met on it.
    viewed: restored.visited,
    // Seconds accrued on each screen, restored coarsely: a viewed screen is
    // credited its minimum, which is all the LMS needs and keeps suspend_data small.
    accrued: screens.map((s, i) => (restored.visited[i] ? s.seconds : 0)),
    narrationPlayed: screens.map((s, i) => restored.visited[i]),
    elapsedSeconds: restored.elapsedSeconds,
    reportedComplete: false,
  };

  const el = {
    screens: new Map(),
    navLinks: new Map(),
    next: document.querySelector('[data-next]'),
    back: document.querySelector('[data-back]'),
    status: document.querySelector('[data-status]'),
    announce: document.querySelector('[data-announce]'),
    timer: document.querySelector('[data-seat-timer]'),
    gate: document.querySelector('[data-seat-gate]'),
    ring: document.querySelector('[data-seat-ring]'),
    count: document.querySelector('[data-seat-count]'),
    progressFill: document.querySelector('[data-progress-fill]'),
    progressLabel: document.querySelector('[data-progress-label]'),
    progressBar: document.querySelector('[data-progress-bar]'),
    resumeBanner: document.querySelector('[data-resume-banner]'),
    doneBanner: document.querySelector('[data-module-complete]'),
  };

  for (const screen of screens) {
    const node = document.querySelector(`[data-screen-id="${CSS.escape(screen.id)}"]`);
    if (node) el.screens.set(screen.id, node);
    const link = document.querySelector(`[data-goto="${CSS.escape(screen.id)}"]`);
    if (link) el.navLinks.set(screen.id, link);
  }

  // Interactions are appended, never overwritten. On a resume the LMS already
  // holds the ones written in an earlier session, so the next index is its
  // count -- starting from 0 would quietly overwrite the first session's
  // answers with this one's.
  let interactionIndex = Number(runtime.getValue('interactionsCount')) || 0;

  /* ---- knowledge checks ---------------------------------------------------- */

  /**
   * The ungraded knowledge checks.
   *
   * The storyboards are specific about these and the specifics matter: single
   * select, one attempt, highlight the correct option and show the feedback on
   * submit, "not scored; not reported to the LMS as a grade", and the screen is
   * complete once every item has been answered.
   *
   * So they are reported as SCORM interactions and never as score. An
   * interaction is exactly what an ungraded practice response is, and giving it
   * a weighting of 0 says so in the data model: a conformant LMS that rolls up
   * interactions cannot pull a practice answer into the grade. The examination
   * SCOs are the only thing in this build that writes cmi.score.
   */
  const knowledgeChecks = new Map();   // screen index -> { total, answered }

  for (const [id, node] of el.screens) {
    const section = node.querySelector('[data-knowledge-check]');
    if (!section) continue;
    const index = indexById.get(id);
    const items = [...section.querySelectorAll('[data-kc-item]')];
    knowledgeChecks.set(index, { total: items.length, answered: new Set() });

    for (const item of items) {
      const check = item.querySelector('[data-kc-check]');
      const feedback = item.querySelector('[data-kc-feedback]');
      const verdict = item.querySelector('[data-kc-verdict]');
      const options = [...item.querySelectorAll('[data-kc-option]')];
      const correct = item.dataset.kcCorrect;
      const shownAt = Date.now();

      // Without scripting the feedback is simply part of the page, which is the
      // right failure: the learner reads the question and its answer. Hiding it
      // is the first thing the enhancement does.
      feedback.hidden = true;

      for (const option of options) {
        option.addEventListener('change', () => { check.disabled = false; });
      }

      check.addEventListener('click', () => {
        const chosen = options.find((o) => o.checked);
        if (!chosen) return;
        const right = chosen.value === correct;

        for (const option of options) {
          option.disabled = true;                       // one attempt
          const row = option.closest('.choice');
          const state = option.value === correct ? 'correct'
            : option === chosen ? 'chosen' : '';
          if (!state) continue;
          row.dataset.kcState = state;

          // Real text in the document, not CSS generated content.
          //
          // These two labels used to be `content` on a ::after pseudo-element.
          // Chromium puts generated content in the accessibility tree, so it
          // read correctly there and the Chromium-based checks passed -- but
          // Firefox does not expose it the same way, and NVDA with Firefox is
          // one of the pairings this project commits to testing. In that
          // pairing the only thing distinguishing the right answer from the
          // learner's wrong one was colour, which is 1.4.1 straightforwardly
          // failed. Generated content also disappears if the stylesheet does.
          const marker = document.createElement('span');
          marker.className = 'choice__mark';
          marker.dataset.kcMark = state;
          marker.textContent = state === 'correct' ? 'Correct answer' : 'Your answer';
          (row.querySelector('label') || row).append(marker);
        }
        item.dataset.kcAnswered = right ? 'correct' : 'incorrect';
        verdict.textContent = right ? 'Correct.' : 'Not quite.';
        feedback.hidden = false;
        check.hidden = true;
        // The button that had focus has just gone. Without this the browser
        // falls back to the top of the document and a keyboard learner has to
        // tab all the way down again to reach the next question.
        feedback.focus();

        // Credit the answer before reporting it. Reporting talks to the LMS,
        // and an LMS that rejects a call or is not there at all must not be able
        // to leave the learner on a screen they have finished: progress is the
        // learner's, the report is the LMS's.
        const record = knowledgeChecks.get(index);
        record.answered.add(item.dataset.kcId);
        const progress = section.querySelector('[data-kc-progress]');
        if (progress) {
          progress.textContent = record.answered.size >= record.total
            ? 'Both questions answered. You can continue.'
            : `${record.answered.size} of ${record.total} answered.`;
        }
        render();

        try {
          runtime.setInteraction(interactionIndex, {
            id: item.dataset.kcId,
            type: 'choice',
            learnerResponse: chosen.value,
            correctResponse: correct,
            correct: right,
            weighting: 0,                                // practice, never part of a grade
            description: item.querySelector('.kc__legend')?.textContent?.trim().slice(0, 250),
            latencySeconds: Math.round((Date.now() - shownAt) / 1000),
          });
          interactionIndex += 1;
        } catch (err) {
          console.warn('[scorm] knowledge-check interaction not reported', err);
        }
      });
    }
  }

  /* ---- practice activities ------------------------------------------------- */

  /**
   * The practice activities, which are not graded either.
   *
   * Two kinds are built so far and the storyboards specify each exactly:
   * a sequencing activity (order the steps; two attempts, then the answer is
   * shown) and binary scenario cards (one profile at a time, one attempt each,
   * feedback immediately). Both report as SCORM interactions at weighting 0,
   * like the knowledge checks -- practice is never part of a grade.
   */
  const practice = new Map();   // screen index -> { total, done, label }

  const reportInteraction = (payload) => {
    try {
      runtime.setInteraction(interactionIndex, { weighting: 0, ...payload });
      interactionIndex += 1;
    } catch (err) {
      console.warn('[scorm] interaction not reported', err);
    }
  };

  for (const [id, node] of el.screens) {
    const index = indexById.get(id);
    const sequence = node.querySelector('[data-interaction="sequence"]');
    const binary = node.querySelector('[data-interaction="binary"]');
    if (!sequence && !binary) continue;

    // One activity that fails to wire up must not take the module down with it.
    // Navigation, seat time and the other 22 screens are worth more than this
    // one screen's interactivity, so a failure here leaves the activity inert
    // and releases its hold on Next rather than stranding the learner.
    try {

    if (sequence) {
      const list = sequence.querySelector('[data-seq-list]');
      const check = sequence.querySelector('[data-seq-check]');
      const feedback = sequence.querySelector('[data-seq-feedback]');
      const left = sequence.querySelector('[data-seq-attempts-left]');
      const allowed = Number(sequence.dataset.seqAttempts) || 2;
      const accepted = config.accepted?.[id] || [];
      const startedAt = Date.now();
      let used = 0;

      practice.set(index, { total: 1, done: 0, label: 'Put the steps in order and select Check.' });

      const cards = () => [...list.querySelectorAll('[data-seq-card]')];
      const renumber = () => cards().forEach((card, i) => {
        const position = card.querySelector('[data-seq-position]');
        if (position) position.textContent = String(i + 1);
      });
      const attemptsNote = () => {
        const remaining = allowed - used;
        left.textContent = remaining > 0
          ? `${remaining} attempt${remaining === 1 ? '' : 's'} left`
          : '';
      };

      const move = (card, delta) => {
        const all = cards();
        const at = all.indexOf(card);
        const to = at + delta;
        if (to < 0 || to >= all.length) return;
        if (delta < 0) list.insertBefore(card, all[to]);
        else list.insertBefore(all[to], card);
        renumber();
      };

      list.addEventListener('click', (event) => {
        const up = event.target.closest('[data-seq-up]');
        const down = event.target.closest('[data-seq-down]');
        if (!up && !down) return;
        const card = event.target.closest('[data-seq-card]');
        move(card, up ? -1 : 1);
        (up || down).focus();
      });

      // Pointer dragging, in addition to the move controls rather than instead
      // of them: the controls are what make this usable by keyboard.
      let dragging = null;
      list.addEventListener('dragstart', (event) => {
        dragging = event.target.closest('[data-seq-card]');
        if (dragging) dragging.dataset.seqDragging = 'true';
      });
      list.addEventListener('dragend', () => {
        if (dragging) delete dragging.dataset.seqDragging;
        dragging = null;
        renumber();
      });
      list.addEventListener('dragover', (event) => {
        if (!dragging) return;
        event.preventDefault();
        const over = event.target.closest('[data-seq-card]');
        if (!over || over === dragging) return;
        const all = cards();
        const before = all.indexOf(dragging) > all.indexOf(over);
        list.insertBefore(dragging, before ? over : over.nextSibling);
      });

      const lockCorrect = () => {
        const order = cards().map((c) => c.dataset.seqLetter);
        // Lock a card when every accepted order agrees it belongs where it is.
        cards().forEach((card, i) => {
          const settled = accepted.every((a) => a[i] === order[i]);
          card.dataset.seqMark = settled ? 'correct' : '';
          const mark = card.querySelector('[data-seq-mark]');
          if (mark) mark.textContent = settled ? '\u2713' : '';
        });
      };

      const finish = (correct, text) => {
        feedback.textContent = text;
        feedback.dataset.seqResult = correct ? 'correct' : 'revealed';
        check.hidden = true;
        left.textContent = '';
        feedback.focus();                                // Check has just gone
        for (const card of cards()) {
          card.draggable = false;
          for (const button of card.querySelectorAll('[data-seq-up],[data-seq-down]')) button.disabled = true;
        }
        const record = practice.get(index);
        record.done = 1;
        render();
      };

      check.addEventListener('click', () => {
        const order = cards().map((c) => c.dataset.seqLetter).join('');
        const correct = accepted.includes(order);
        used += 1;
        lockCorrect();

        reportInteraction({
          id: `${id}-sequence`,
          type: 'sequencing',
          learnerResponse: cards().map((c) => c.dataset.seqLetter).join(','),
          correctResponse: (accepted[0] || '').split('').join(','),
          correct,
          description: 'Practice: put the commission steps in order',
          latencySeconds: Math.round((Date.now() - startedAt) / 1000),
        });

        if (correct) { finish(true, config.feedback?.[id]?.correct || 'Correct.'); return; }
        if (used >= allowed) {
          // "Two attempts, then show the correct order with explanation."
          const byLetter = new Map(cards().map((c) => [c.dataset.seqLetter, c]));
          for (const letter of accepted[0].split('')) {
            const card = byLetter.get(letter);
            if (card) list.appendChild(card);
          }
          renumber();
          lockCorrect();
          finish(false, config.feedback?.[id]?.incorrect || 'Here is the correct order.');
          return;
        }
        feedback.textContent = config.feedback?.[id]?.incorrect || 'Not quite. Try again.';
        feedback.dataset.seqResult = 'retry';
        attemptsNote();
      });

      attemptsNote();
    }

    if (binary) {
      const cards = [...binary.querySelectorAll('[data-binary-card]')];
      const tally = binary.querySelector('[data-binary-tally]');
      let answered = 0;
      let right = 0;
      let shown = 0;

      practice.set(index, { total: cards.length, done: 0, label: 'Answer every case to continue.' });

      const updateTally = () => {
        tally.textContent = answered >= cards.length
          ? `All ${cards.length} answered \u2014 ${right} correct.`
          : `Case ${shown + 1} of ${cards.length}\u2003${right} of ${answered} correct so far.`;
      };

      cards.forEach((card, index2) => {
        const feedback = card.querySelector('[data-binary-feedback]');
        const verdict = card.querySelector('[data-binary-verdict]');
        const rule = card.querySelector('[data-binary-rule]');
        const advance = card.querySelector('[data-binary-advance]');
        const correctText = card.querySelector('.binary__correct-text');
        const incorrectText = card.querySelector('.binary__incorrect-text');
        const next = card.querySelector('[data-binary-next]');
        const choices = [...card.querySelectorAll('[data-binary-choice]')];
        const startedAt = Date.now();

        if (feedback) feedback.hidden = true;
        if (advance) advance.hidden = true;
        if (next && index2 === cards.length - 1) next.textContent = 'Finish';

        for (const button of choices) {
          button.addEventListener('click', () => {
            const chosen = button.dataset.binaryChoice;
            const correct = chosen === card.dataset.binaryAnswer;
            answered += 1;
            if (correct) right += 1;

            for (const other of choices) {
              other.disabled = true;                      // one attempt per card
              if (other.dataset.binaryChoice === chosen) other.dataset.binaryChosen = 'true';
            }
            card.dataset.binaryResult = correct ? 'correct' : 'incorrect';
            verdict.textContent = correct ? 'Correct.' : 'Not quite.';
            rule.textContent = (correct ? correctText : incorrectText).textContent;
            feedback.hidden = false;
            // The last card has nothing to advance to.
            if (advance) advance.hidden = index2 === cards.length - 1;
            // Both choice buttons are now disabled, so focus would be lost.
            feedback.focus();

            const record = practice.get(index);
            record.done = answered;
            updateTally();
            render();

            reportInteraction({
              id: card.dataset.binaryId,
              type: 'true-false',
              learnerResponse: chosen === 'yes' ? 'true' : 'false',
              correctResponse: card.dataset.binaryAnswer === 'yes' ? 'true' : 'false',
              correct,
              description: card.querySelector('.binary__prompt')?.textContent?.trim().slice(0, 250),
              latencySeconds: Math.round((Date.now() - startedAt) / 1000),
            });
          });
        }

        next.addEventListener('click', () => {
          card.hidden = true;
          const following = cards[index2 + 1];
          if (following) {
            following.hidden = false;
            shown = index2 + 1;
            updateTally();
            following.querySelector('[data-binary-choice]')?.focus();
          }
        });
      });

      updateTally();
    }

    } catch (err) {
      console.error(`[activity] ${id} could not be wired up; it will not hold the learner`, err);
      practice.delete(index);
    }
  }

  /**
   * A screen with an activity on it is done when the activity is done: every
   * knowledge-check item answered, every scenario card answered, the sequence
   * solved or its answer shown. The storyboards set these completion rules
   * screen by screen and they are what the Next button waits for.
   */
  const activitySatisfied = (i) => {
    const kc = knowledgeChecks.get(i);
    if (kc && kc.answered.size < kc.total) return false;
    const activity = practice.get(i);
    if (activity && activity.done < activity.total) return false;
    return true;
  };

  /* ---- narration gating --------------------------------------------------- */

  // Which screens the learner has actually started playing. See below.
  const narrationStarted = screens.map(() => false);

  /**
   * Replaces the browser's own audio chrome with controls that belong to this
   * page.
   *
   * Progressive enhancement, deliberately: the HTML ships `<audio controls>`, so
   * with scripting unavailable the learner still gets a working player, and the
   * native controls are only removed once there is something to replace them
   * with. Everything here is a real `<button>` and a real `<input type="range">`
   * -- the keyboard behaviour, focus handling and screen-reader semantics are
   * the platform's, not ours.
   *
   * It also puts the caption file to work. A browser never renders captions for
   * an audio element, because there is no picture to put them on, so the VTT we
   * ship was readable by an LMS and by nothing else. Following the cues here
   * gives every learner the words as they are spoken.
   */
  function enhanceAudio(audio) {
    audio.removeAttribute('controls');

    const bar = document.createElement('div');
    bar.className = 'player';
    bar.innerHTML = `
      <button type="button" class="player__toggle" data-player-toggle aria-pressed="false">
        <span class="visually-hidden" data-player-label>Play the narration</span>
        <svg class="player__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <path class="player__play" d="M8.5 5.4v13.2l10.2-6.6z"></path>
          <g class="player__pause">
            <rect x="7.6" y="5.4" width="3.4" height="13.2" rx="1.1"></rect>
            <rect x="13" y="5.4" width="3.4" height="13.2" rx="1.1"></rect>
          </g>
        </svg>
      </button>
      <input class="player__seek" type="range" min="0" max="1000" step="1" value="0"
        data-player-seek aria-label="Position in the narration">
      <span class="player__clock" data-player-clock>0:00</span>
    `;
    const caption = document.createElement('p');
    caption.className = 'player__caption';
    // The transcript already gives screen-reader users this text in full, and
    // announcing every cue as it changes would talk over the narration itself.
    caption.setAttribute('aria-hidden', 'true');

    audio.insertAdjacentElement('afterend', bar);
    bar.insertAdjacentElement('afterend', caption);

    const toggle = bar.querySelector('[data-player-toggle]');
    const label = bar.querySelector('[data-player-label]');
    const seek = bar.querySelector('[data-player-seek]');
    const clock = bar.querySelector('[data-player-clock]');

    const clockText = (seconds) => {
      const whole = Math.max(0, Math.round(seconds || 0));
      return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
    };

    let scrubbing = false;

    // preload="none" means the real duration is unknown until the learner
    // presses play. The measured duration travels in the markup so the clock
    // reads "0:00 / 0:25" from the start instead of appearing to grow a total.
    const declared = Number(audio.dataset.duration) || 0;

    const paint = () => {
      const duration = Number.isFinite(audio.duration) && audio.duration > 0
        ? audio.duration
        : declared;
      const position = duration ? audio.currentTime / duration : 0;
      if (!scrubbing) seek.value = String(Math.round(position * 1000));
      bar.style.setProperty('--player-progress', `${(position * 100).toFixed(2)}%`);
      clock.textContent = duration
        ? `${clockText(audio.currentTime)} / ${clockText(duration)}`
        : clockText(audio.currentTime);
      seek.setAttribute('aria-valuetext', duration
        ? `${clockText(audio.currentTime)} of ${clockText(duration)}`
        : 'Not yet loaded');
    };

    /**
     * How long the narration runs, in words.
     *
     * The build writes the duration onto the audio element, so it is known
     * before the file has loaded -- which matters, because the announcement a
     * learner hears is the one made when they arrive at the control, not the
     * one it would make a few seconds later.
     */
    const spokenDuration = () => {
      const seconds = Number(audio.dataset.duration) || audio.duration;
      if (!Number.isFinite(seconds) || seconds <= 0) return '';
      const whole = Math.round(seconds);
      if (whole < 60) return `, ${whole} seconds`;
      const minutes = Math.floor(whole / 60);
      const rest = whole % 60;
      const mins = `${minutes} minute${minutes === 1 ? '' : 's'}`;
      return rest ? `, ${mins} ${rest} seconds` : `, ${mins}`;
    };

    const paintState = () => {
      const playing = !audio.paused && !audio.ended;
      bar.dataset.playing = playing ? 'true' : 'false';
      toggle.setAttribute('aria-pressed', playing ? 'true' : 'false');
      // The duration rides along with the name. Reaching a play control and
      // being told only "play" leaves the learner to commit to something of
      // unknown length -- and on a gated screen, length is what they are
      // deciding about.
      label.textContent = (playing ? 'Pause the narration' : 'Play the narration')
        + spokenDuration();
    };

    toggle.addEventListener('click', () => {
      if (audio.paused || audio.ended) audio.play().catch(() => {});
      else audio.pause();
    });

    seek.addEventListener('pointerdown', () => { scrubbing = true; });
    seek.addEventListener('keydown', () => { scrubbing = true; });
    const commitSeek = () => {
      if (Number.isFinite(audio.duration)) {
        audio.currentTime = (Number(seek.value) / 1000) * audio.duration;
      }
      scrubbing = false;
      paint();
    };
    seek.addEventListener('change', commitSeek);
    seek.addEventListener('input', () => {
      // Paint the track while dragging, but only move the audio on commit, so a
      // drag does not fire a seek for every pixel.
      bar.style.setProperty('--player-progress', `${(Number(seek.value) / 10).toFixed(2)}%`);
    });

    for (const event of ['play', 'pause', 'ended']) audio.addEventListener(event, paintState);
    for (const event of ['timeupdate', 'durationchange', 'loadedmetadata', 'seeked']) {
      audio.addEventListener(event, paint);
    }

    const track = audio.textTracks && audio.textTracks[0];
    if (track) {
      // 'hidden' loads and fires cues without asking the browser to draw them.
      track.mode = 'hidden';
      track.addEventListener('cuechange', () => {
        const cue = track.activeCues && track.activeCues[0];
        caption.textContent = cue ? cue.text.replace(/\s*\n\s*/g, ' ') : '';
      });
    }
    audio.addEventListener('ended', () => { caption.textContent = ''; });

    paint();
    paintState();
  }

  for (const [id, node] of el.screens) {
    const audio = node.querySelector('[data-narration]');
    if (!audio) continue;
    const index = indexById.get(id);
    enhanceAudio(audio);
    audio.addEventListener('play', () => { narrationStarted[index] = true; render(); });
    audio.addEventListener('ended', () => {
      state.narrationPlayed[index] = true;
      render();
    });
    // A track that starts and then fails would otherwise hold the screen for
    // ever: "play" armed the gate and "ended" is never coming. Releasing the
    // audio half puts the learner back on the transcript path, which is the
    // same place a learner who never pressed play is, rather than stranding
    // them on a screen they cannot leave.
    for (const event of ['error', 'abort']) {
      audio.addEventListener(event, () => { narrationStarted[index] = false; render(); });
    }
  }

  /**
   * The storyboards say Next unlocks when the narration ends AND the minimum has
   * elapsed, with no fast-forwarding on first view.
   *
   * Applied literally that locks out exactly the learners the narration is least
   * use to. A Deaf or hard-of-hearing learner, or anyone working somewhere they
   * cannot play audio, reads the transcript that every screen carries -- and
   * would never be able to advance, because an audio element they never played
   * never fires "ended". That is a WCAG failure, not a stricter course.
   *
   * So the rule is applied this way: once a learner starts the narration they
   * must let it finish, which is what "no fast-forwarding" is for; a learner who
   * never starts it is held by the screen minimum alone, with the transcript as
   * their equivalent. Both paths take at least the full storyboarded time.
   *
   * This is a deliberate deviation from the storyboards' wording and is recorded
   * in docs/open-questions.md for the Secretary of the Commonwealth to confirm.
   */
  const narrationSatisfied = (i) => {
    const node = el.screens.get(screens[i].id);
    if (!node?.querySelector('[data-narration]')) return true;   // none produced yet
    if (state.narrationPlayed[i]) return true;                   // played to the end
    return !narrationStarted[i];                                 // never started: transcript path
  };

  const timeSatisfied = (i) => state.accrued[i] >= screens[i].seconds;
  const screenComplete = (i) => timeSatisfied(i) && narrationSatisfied(i) && activitySatisfied(i);

  function furthestUnlocked() {
    if (config.navigation.allowFreeNavigation) return screenCount - 1;
    for (let i = 0; i < screenCount; i += 1) {
      if (!state.viewed[i] || !screenComplete(i)) return i;
    }
    return screenCount - 1;
  }

  const moduleComplete = () => state.viewed.every(Boolean) && screens.every((_, i) => screenComplete(i));

  /* ---- rendering ---------------------------------------------------------- */

  // Which gate state was last announced, so a tick that merely decrements the
  // countdown stays silent. null until the first render, which announces nothing.
  let lastGate = null;

  function render(options = {}) {
    const unlocked = furthestUnlocked();

    for (const [id, node] of el.screens) {
      node.hidden = indexById.get(id) !== state.index;
    }

    for (const [id, link] of el.navLinks) {
      const i = indexById.get(id);
      const current = i === state.index;
      const done = state.viewed[i] && screenComplete(i);
      const locked = i > unlocked;
      link.setAttribute('aria-current', current ? 'page' : 'false');
      link.disabled = locked && !current;
      link.classList.toggle('navlink--done', done);
      link.classList.toggle('navlink--locked', locked);
      const marker = link.querySelector('[data-state]');
      if (marker) marker.textContent = done ? '✓' : locked ? '•' : '○';
      const sr = link.querySelector('[data-state-sr]');
      if (sr) sr.textContent = done ? ' (completed)' : locked ? ' (not yet available)' : '';
    }

    const i = state.index;
    const remaining = Math.max(0, Math.ceil(screens[i].seconds - state.accrued[i]));
    const canAdvance = i < screenCount - 1 && screenComplete(i);

    if (el.next) {
      el.next.hidden = i === screenCount - 1;
      // Not the `disabled` property: that removes the button from the tab
      // order, so a keyboard or screen-reader user never reaches it while the
      // gate holds and never hears the reason it is holding. aria-disabled
      // announces "unavailable" and stays reachable. The press is refused in
      // the click handler instead of by the browser.
      el.next.setAttribute('aria-disabled', canAdvance ? 'false' : 'true');
    }
    if (el.back) el.back.disabled = i === 0 || !config.navigation.allowBackward;

    // The wait is shown as a depleting ring beside Next, with the seconds left
    // in the middle. The sentence form of the same thing goes to the live
    // region, which is what a screen reader announces.
    const waitingOnAudio = timeSatisfied(i) && !narrationSatisfied(i);
    const waitingOnActivity = timeSatisfied(i) && narrationSatisfied(i) && !activitySatisfied(i);
    const settled = screenComplete(i);

    if (el.gate) {
      el.gate.hidden = settled || i === screenCount - 1;
      el.gate.dataset.waiting = waitingOnActivity ? 'activity' : waitingOnAudio ? 'narration' : 'time';
    }
    if (el.ring) {
      // The ring empties as the minimum accrues: offset 0 draws the whole
      // circle, offset == circumference draws none of it.
      const circumference = 2 * Math.PI * 20;
      const elapsed = screens[i].seconds > 0
        ? Math.min(1, state.accrued[i] / screens[i].seconds)
        : 1;
      // Waiting on the narration, the clock is already full, so an elapsed-driven
      // ring would be empty -- an invisible indicator at the moment the learner
      // most needs to know they are still held. Draw it whole instead: a
      // complete ring in the caution colour around the note.
      el.ring.style.setProperty('--ring-circumference', circumference.toFixed(2));
      el.ring.style.setProperty('--ring-offset',
        waitingOnAudio || waitingOnActivity ? '0' : (circumference * elapsed).toFixed(2));
    }
    if (el.count) {
      el.count.textContent = waitingOnActivity ? '?' : waitingOnAudio ? '\u266a' : String(remaining);
    }

    if (el.timer) {
      const activity = knowledgeChecks.get(i);
      el.timer.textContent = settled
        ? ''
        : waitingOnActivity
          ? (activity
            ? `${activity.total - activity.answered.size === 1 ? 'Answer the remaining question' : 'Answer both questions'} to continue.`
            : practice.get(i)?.label || 'Finish the activity to continue.')
          : waitingOnAudio
            ? 'Play the narration to the end to continue.'
            : `${remaining} second${remaining === 1 ? '' : 's'} remaining on this screen.`;
    }

    // What a screen reader should hear is that the gate changed, not the
    // count ticking down. Three states: waiting on the clock, on the
    // narration, on an activity -- plus open. A tick that only decrements the
    // number announces nothing.
    const gate = settled ? 'open'
      : waitingOnActivity ? 'activity'
        : waitingOnAudio ? 'narration' : 'time';
    const gateChanged = lastGate !== null && gate !== lastGate;
    lastGate = gate;

    const viewedCount = state.viewed.filter(Boolean).length;
    const percent = Math.round((viewedCount / screenCount) * 100);
    if (el.progressFill) el.progressFill.style.width = `${percent}%`;
    if (el.progressLabel) el.progressLabel.textContent = `${percent}% complete`;
    if (el.progressBar) {
      el.progressBar.setAttribute('aria-valuenow', String(percent));
      el.progressBar.setAttribute('aria-valuetext', `${viewedCount} of ${screenCount} screens completed`);
    }
    if (el.status) {
      // The lesson name is on the screen itself and highlighted in the contents,
      // so the bar stays short enough not to wrap at any width.
      el.status.textContent = `Screen ${i + 1} of ${screenCount}`;
    }
    if (el.doneBanner) el.doneBanner.hidden = !moduleComplete();

    if (moduleComplete() && !state.reportedComplete) {
      state.reportedComplete = true;
      reportCompletion();
    }

    if (options.announce && el.announce) {
      // Navigating announces the screen. It arrives with the gate reset, so
      // the reset is not itself news.
      el.announce.textContent = `${screens[i].title}. Screen ${i + 1} of ${screenCount}.`;
    } else if (gateChanged && el.announce) {
      el.announce.textContent = gate === 'open'
        ? 'Next is now available.'
        : (el.timer ? el.timer.textContent : '');
    }
    if (options.focus) {
      el.screens.get(screens[i].id)?.querySelector('[data-screen-heading]')?.focus();
    }
  }

  /* ---- navigation --------------------------------------------------------- */

  function goTo(target, options = {}) {
    const next = Math.max(0, Math.min(screenCount - 1, target));
    if (next > furthestUnlocked()) return;
    state.index = next;
    state.viewed[next] = state.viewed[next] || screenComplete(next);
    persist();
    render({ announce: true, focus: options.focus !== false });
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  el.next?.addEventListener('click', () => {
    if (el.next.getAttribute('aria-disabled') === 'true') {
      // A press that does nothing and says nothing reads as a broken button.
      // Say what is still outstanding, in the region that gets announced.
      if (el.announce && el.timer) el.announce.textContent = el.timer.textContent;
      return;
    }
    goTo(state.index + 1);
  });
  el.back?.addEventListener('click', () => goTo(state.index - 1));
  for (const [id, link] of el.navLinks) {
    link.addEventListener('click', () => goTo(indexById.get(id)));
  }

  /* ---- seat time ---------------------------------------------------------- */

  let lastTick = Date.now();
  let lastActivity = Date.now();
  const sessionStart = Date.now();

  for (const event of ['pointerdown', 'keydown', 'wheel', 'touchstart']) {
    window.addEventListener(event, () => { lastActivity = Date.now(); }, { passive: true });
  }

  setInterval(() => {
    const now = Date.now();
    const delta = (now - lastTick) / 1000;
    lastTick = now;
    const present = document.visibilityState === 'visible' && now - lastActivity < IDLE_AFTER_MS;
    if (!present) return;

    const i = state.index;
    const wasComplete = screenComplete(i);
    state.accrued[i] += delta;
    state.elapsedSeconds += delta;
    if (!state.viewed[i] && screenComplete(i)) state.viewed[i] = true;
    // Re-render on the second boundary, and whenever the screen unlocks.
    if (!wasComplete || Math.floor(state.accrued[i]) !== Math.floor(state.accrued[i] - delta)) render();
  }, TICK_MS);

  /* ---- SCORM -------------------------------------------------------------- */

  function persist() {
    runtime.setValue(
      'suspendData',
      encodeState({
        pageIndex: state.index,
        visited: state.viewed,
        knowledgeChecks: {},
        elapsedSeconds: Math.round(state.elapsedSeconds),
        acknowledgements: [],
      }),
    );
    runtime.setValue('lessonLocation', screens[state.index].id);
    runtime.setProgress({
      complete: moduleComplete(),
      progress: state.viewed.filter(Boolean).length / screenCount,
    });
  }

  function reportCompletion() {
    runtime.setProgress({ complete: true, progress: 1 });
    runtime.setValue('sessionTime', runtime.formatDuration((Date.now() - sessionStart) / 1000));
    runtime.commit();
    if (el.announce) {
      el.announce.textContent =
        `${config.moduleTitle} complete. Your completion has been recorded. Return to the course to continue.`;
    }
  }

  setInterval(() => { persist(); runtime.commit(); }, COMMIT_INTERVAL_MS);

  let finished = false;
  function finish() {
    if (finished) return;
    finished = true;
    persist();
    runtime.setValue('sessionTime', runtime.formatDuration((Date.now() - sessionStart) / 1000));
    if (!moduleComplete()) runtime.setSuspendExit();
    runtime.commit();
    runtime.terminate();
  }
  window.addEventListener('pagehide', finish);
  window.addEventListener('beforeunload', finish);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') { persist(); runtime.commit(); }
  });

  /* ---- chrome ------------------------------------------------------------- */

  const themeToggle = document.querySelector('[data-theme-toggle]');
  const describeTheme = (value) => {
    const name = value === 'dark' ? 'dark' : value === 'light' ? 'light' : 'follows your system';
    themeToggle?.setAttribute('aria-label', `Display theme: ${name}. Activate to change.`);
  };
  themeToggle?.addEventListener('click', () => {
    const root = document.documentElement;
    const current = root.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : current === 'light' ? '' : 'dark';
    if (next) root.setAttribute('data-theme', next);
    else root.removeAttribute('data-theme');
    // The name has to follow the state, or the control announces the theme the
    // learner just left.
    describeTheme(next);
    try { localStorage.setItem('va-notary-theme', next); } catch { /* storage may be blocked */ }
  });
  try {
    const saved = localStorage.getItem('va-notary-theme');
    if (saved) {
      document.documentElement.setAttribute('data-theme', saved);
      describeTheme(saved);
    }
  } catch { /* storage may be blocked */ }

  const navToggle = document.querySelector('[data-nav-toggle]');
  navToggle?.addEventListener('click', () => {
    const nav = document.querySelector('.coursenav');
    const open = nav?.dataset.open === 'true';
    if (nav) nav.dataset.open = open ? 'false' : 'true';
    navToggle.setAttribute('aria-expanded', open ? 'false' : 'true');
  });

  if (el.resumeBanner) el.resumeBanner.hidden = !(restored.recovered && state.index > 0);

  render({ announce: false, focus: false });
  persist();
  runtime.commit();

  return { state, runtime, goTo, render, screens, moduleComplete };
}


/* ---- boot -------------------------------------------------------------- */
var node = document.getElementById('module-config');
if (node) {
  try {
    window.__vaNotaryModule = startModule(JSON.parse(node.textContent));
  } catch (err) {
    console.error('Module failed to start', err);
    var banner = document.createElement('div');
    banner.className = 'banner';
    banner.setAttribute('role', 'alert');
    banner.textContent = 'This module could not start. Reload the page, and if the problem persists '
      + 'report it to your learning system administrator. Nothing you have done has been lost.';
    document.getElementById('content').prepend(banner);
  }
}
}());
